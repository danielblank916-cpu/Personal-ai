package com.example.personalaicompanion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF9A8CFF),
                secondary = Color(0xFF65D6CE),
                background = Color(0xFF10111A),
                surface = Color(0xFF191B28)
            )) {
                CompanionScreen()
            }
        }
    }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
private fun CompanionScreen() {
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                "Hi! I'm your Personal AI Companion. Once you connect a secure AI backend, I'll be able to answer your questions. This starter version does not pretend to have an AI connection before one is configured.",
                false
            )
        )
    }
    var input by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    val scope = rememberCoroutineScope()

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF10111A)) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(46.dp).background(
                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            listOf(Color(0xFF7867FF), Color(0xFF45D6CE))
                        ),
                        shape = CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("AI", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text("Personal AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(status, color = Color(0xFFB8B9CA), fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (message.fromUser) Color(0xFF5145B8) else Color(0xFF202334),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth(0.88f)
                        ) {
                            Text(
                                message.text,
                                modifier = Modifier.padding(13.dp),
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
                if (isLoading) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text(" Connecting…", color = Color.LightGray)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message your AI…") },
                    enabled = !isLoading,
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp)
                )
                Button(
                    onClick = {
                        val question = input.trim()
                        if (question.isNotEmpty() && !isLoading) {
                            messages.add(ChatMessage(question, true))
                            input = ""
                            if (BuildConfig.AI_BACKEND_URL.isBlank()) {
                                messages.add(
                                    ChatMessage(
                                        "The chat screen is ready, but the AI backend is not connected yet. Next, deploy the secure backend and set AI_BACKEND_URL when building. No fake AI response was generated.",
                                        false
                                    )
                                )
                                status = "Backend not connected"
                            } else {
                                isLoading = true
                                status = "Thinking…"
                                scope.launch {
                                    val result = requestAssistantReply(question)
                                    messages.add(ChatMessage(result, false))
                                    isLoading = false
                                    status = if (result.startsWith("Connection error:")) "Connection problem" else "Ready"
                                }
                            }
                        }
                    },
                    enabled = input.isNotBlank() && !isLoading,
                    modifier = Modifier.padding(start = 8.dp).size(52.dp),
                    shape = CircleShape
                ) {
                    androidx.compose.material3.Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
            Text(
                "Starter build • Voice, live search and memory are added in later steps",
                modifier = Modifier.padding(top = 8.dp),
                color = Color(0xFF999BAD),
                fontSize = 11.sp
            )
        }
    }
}

private suspend fun requestAssistantReply(message: String): String = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
        val baseUrl = BuildConfig.AI_BACKEND_URL.trim().trimEnd('/')
        connection = (URL("$baseUrl/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject().put("message", message).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            "Connection error: backend returned HTTP $code. Check the backend deployment."
        } else {
            val json = JSONObject(response)
            json.optString("reply").takeIf { it.isNotBlank() }
                ?: "The backend responded, but its JSON did not contain a non-empty 'reply' field."
        }
    } catch (e: Exception) {
        "Connection error: ${e.message ?: "Could not reach the backend"}. Check your internet connection and backend URL."
    } finally {
        connection?.disconnect()
    }
}

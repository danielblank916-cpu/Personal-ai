package com.neopuzzleassistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private ImageView preview;
    private TextView results;
    private Button analyzeButton;
    private Uri selectedImage;
    private ImageLabeler labeler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);
        page.setBackgroundColor(Color.rgb(247, 248, 252));

        TextView title = new TextView(this);
        title.setText("NEO Puzzle Assistant");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(26, 36, 70));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 8);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("Choose a puzzle screenshot or image. The assistant will identify visible objects and give you a starting point for solving supported visual puzzles.");
        intro.setTextSize(16);
        intro.setTextColor(Color.DKGRAY);
        intro.setPadding(0, 8, 0, 18);
        page.addView(intro);

        Button chooseButton = new Button(this);
        chooseButton.setText("Choose screenshot or image");
        page.addView(chooseButton, new LinearLayout.LayoutParams(-1, -2));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        imageParams.setMargins(0, 14, 0, 14);
        page.addView(preview, imageParams);

        analyzeButton = new Button(this);
        analyzeButton.setText("Analyze image");
        analyzeButton.setEnabled(false);
        page.addView(analyzeButton, new LinearLayout.LayoutParams(-1, -2));

        results = new TextView(this);
        results.setText("No image selected yet.");
        results.setTextSize(16);
        results.setTextColor(Color.rgb(35, 42, 58));
        results.setPadding(0, 18, 0, 12);
        page.addView(results, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Note: This starter version labels objects; it does not solve every puzzle. CAPTCHA and other human-verification checks must be completed by you.");
        note.setTextSize(13);
        note.setTextColor(Color.GRAY);
        note.setPadding(0, 8, 0, 8);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);

        chooseButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE);
        });

        analyzeButton.setOnClickListener(v -> analyzeSelectedImage());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImage = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedImage, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            preview.setImageURI(selectedImage);
            results.setText("Image selected. Tap Analyze image to identify visible objects.");
            analyzeButton.setEnabled(true);
        }
    }

    private void analyzeSelectedImage() {
        if (selectedImage == null) return;
        results.setText("Analyzing image…");
        analyzeButton.setEnabled(false);
        try {
            InputImage image = InputImage.fromFilePath(this, selectedImage);
            labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        results.setText("No clear object labels found. Try a sharper screenshot or crop the puzzle.");
                    } else {
                        StringBuilder text = new StringBuilder("Objects detected:\n\n");
                        for (ImageLabel label : labels) {
                            text.append("• ").append(label.getText())
                                .append(" — ")
                                .append(String.format(Locale.getDefault(), "%.0f%%", label.getConfidence() * 100))
                                .append(" confidence\n");
                        }
                        text.append("\nThese labels can help describe the image, but they are not a guaranteed puzzle solution.");
                        results.setText(text.toString());
                    }
                    analyzeButton.setEnabled(true);
                })
                .addOnFailureListener(error -> {
                    results.setText("Could not analyze this image. Try another image. Details: " + error.getLocalizedMessage());
                    analyzeButton.setEnabled(true);
                });
        } catch (IOException error) {
            results.setText("Could not open this image. Please choose another one.");
            analyzeButton.setEnabled(true);
        }
    }

    @Override
    protected void onDestroy() {
        if (labeler != null) labeler.close();
        super.onDestroy();
    }
}
